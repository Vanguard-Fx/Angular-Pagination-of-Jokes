import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reverse-string',
  templateUrl: './reverse-string.component.html',
  styleUrls: ['./reverse-string.component.scss']
})
export class ReverseStringComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
